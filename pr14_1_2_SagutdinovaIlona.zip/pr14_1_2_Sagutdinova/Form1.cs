﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using System.IO;

namespace pr14_1_2_Sagutdinova
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Stack<int> stackN = new Stack<int>();
        private void button1_Click(object sender, EventArgs e)
        {
                int n = (int)numericUpDown1.Value;
                for (int i = 1; i <= n; i++)
                { stackN.Push(i);
                }
                int[] arr = stackN.ToArray();
                string ar = "";
                for (int i =0; i<arr.Length;i++)
                {
                    ar += arr[i] + " ";
                }
                string message = $"n = {n}\nРазмерность стека = {stackN.Count}\nВершина стека = {stackN.Peek()}" +
                    $"\nСодержимое стека = {ar}";
                stackN.Clear();
                string mes = $"\nНовая размерность стека {stackN.Count}";
                MessageBox.Show(message+mes); 
        }

        private void button2_Click(object sender, EventArgs e)
        {
            using (StreamWriter sw = File.CreateText("t.txt"))
            {
                sw.WriteLine(textBox1.Text);
            }
            string check;
            using (StreamReader sr = File.OpenText("t.txt"))
            {
                string ex = sr.ReadLine();
                check = Check(ex);
            }
            using (StreamWriter sw = File.CreateText("t1.txt"))
            {
                sw.WriteLine(check);
            }
            MessageBox.Show("Успешно! Проверьте результат в файле t1.txt", "Успешно", MessageBoxButtons.OK);
        }

        
        private string Check(string ex)
        {
            Stack<int> bracketPos = new Stack<int>();
            StringBuilder balanceEx = new StringBuilder(ex);
            List<int> bracketsRemove = new List<int>();
            for (int i = 0; i < balanceEx.Length; i++)
            {
                if (balanceEx[i] == '(')
                    bracketPos.Push(i);
                else if (balanceEx[i] == ')')
                {
                    if (bracketPos.Count > 0)
                        bracketPos.Pop();
                    else
                        bracketsRemove.Add(i);
                }
            }
            while (bracketPos.Count > 0)
                bracketsRemove.Add(bracketPos.Pop());
            bracketsRemove.Sort();
            bracketsRemove.Reverse();
            foreach (int i in bracketsRemove)
                balanceEx.Remove(i, 1);
            return balanceEx.ToString();
        }
    }
}
